= CHILLIGURU =

* Version 1.0
* Updated 10 February 2008
* by PAUL THEWLIS, http://blog.paulthewlis.com


== ABOUT CHILLIGURU ==

The CHILLIGURU design was developed by PAUL THEWLIS for Packt Publishing http://www.packtpub.com.


== DESIGN FILES ==

	/chilliguru_finished_theme/ [FOLDER]
		howtoinstall.txt
		license.txt
		readme.txt
		style.css
		screenshot.png
			/images/ [SUBFOLDER]
				author.gif
				background.jpg
				category.png
				comment.png
				feed.png
				edit.png
				redchilli.jpg
				


== LICENSE ==

The ChilliGuru design for Sandbox, by PAUL THEWLIS, is licensed under the GNU General Public License:

    This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful, but without any warranty; without even the implied warranty of merchantability or fitness for a particular purpose. See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.