
	<div id="footer">
	&copy; Copyright 2008 <a href="http://blog.chilliguru.com">ChilliGuru</a> &nbsp; | &nbsp; Powered by <a href="http://wordpress.org">WordPress</a> &nbsp; | &nbsp; Designed with <a href="http://www.plaintxt.org/themes/sandbox/">The Sandbox</a>
	</div><!-- #footer -->

</div><!-- #wrapper .hfeed -->

<?php wp_footer() ?>

</body>
</html>