Chapter No. 	Contains Code or not ?

Chapter 1			No
Chapter 2			No
Chapter 3			Yes
Chapter 4 			Yes
Chapter 5 			Yes
Chapter 6			No
Chapter 7 			Yes
Chapter 8			Yes
Chapter 9			No
Chapter 10		Yes
Chapter 11			No
